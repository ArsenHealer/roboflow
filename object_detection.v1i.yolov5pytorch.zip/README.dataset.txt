# object_detection > 2022-12-01 9:50am
https://universe.roboflow.com/arsen-petrov-hp3di/object_detection-wyrn0

Provided by a Roboflow user
License: CC BY 4.0

